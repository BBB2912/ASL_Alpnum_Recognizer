from recognize import SignLanguageRecognizer

SignLanguageRecognizer.run_webcam()